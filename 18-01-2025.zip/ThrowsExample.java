package lpu;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class ThrowsExample {
	public static void show() throws FileNotFoundException {
		Scanner sc=new Scanner(new File("C:\\Users\\KASHISH\\eclipse-workspace\\lpu\\src\\lpu\\test.txt"));
		while(sc.hasNext()) {
			System.out.println(sc.next());
		}
	}
	public static void main(String[] args) {
		try {
			show();
		}
		catch(FileNotFoundException e) {
			System.out.println(e);
		}
	}
}

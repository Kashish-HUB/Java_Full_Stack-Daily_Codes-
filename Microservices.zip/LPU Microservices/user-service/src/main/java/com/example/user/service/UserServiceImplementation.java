package com.example.user.service;

import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImplementation implements UserService {
    
    private List<UserServices> list = List.of(
        new UserServices(101L, "Kashish", "9999999"),
        new UserServices(102L, "Pinda", "9999999"),
        new UserServices(103L, "Simer", "9999999"),
        new UserServices(104L, "Diksha", "9999999")
    );

    @Override
    public UserServices getUserbyId(Long id) {
        return list.stream().filter(user -> user.getUsrId().equals(id)).findAny().orElse(null);
    }
}

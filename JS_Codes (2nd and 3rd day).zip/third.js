//Range Error
try{
    let arr1=new Array(1e308);
    console.log(arr1);
} catch(e){
    if(e instanceof RangeError){
        console.log("RangeError: Invalid slice range"+e.message);
    }
else{
    console.log("An error occurred: "+e.message);
}
}

//Reference Error
try{
    console.log(a);
}
catch(error){
    console.log("Reference error occurred",error.message);
}

//Syntax Error
try{
    eval("var x = ;");
}
catch(error){
    if(error instanceof SyntaxError){
        console.error("SyntaxError caught:",error.message);
    }else{
        console.error("An unexpected error occurred:", error.message);
    }
}

//Type Error
//try{
  //  let notAFunction=
//}

//URI Error
//try{
//let encodedURI="https3%3//cyber.success.%%.com";
//let decodeURI=decodeURIComponent(encodedURI);
//eval("var a=;");
//var fun=100;
//fun();
//}catch(error){
  //  if(error instanceof URIError){
    //    console.error("Error caught: ",error.message);
    //}
    //else{
      //  console.error("")
    //}
//}

//This keyword
console.log(this);
var age=30;
const person={
id:101,
name:"Kashish",
age:21,
getAge(){
    setTimeout(()=>{
        console.log(this.age),2000;
    });
},
getAge1:()=>{
    console.log(this.age);
},
};
person.getAge();
person.getAge1();

//Array destructuring
const edible=["food", "fruits"];
let[posone, postwo]=edible;
[posone, postwo]=[postwo,posone];
console.log(posone,postwo);

//Object Destructuring
const person1={
    id:101,
    name:"Simer",
    age:22,
};
const{id:i,name:n,age:a}=person1;
console.log(i + " "+ n +" "+ a +" ");

//Synchronus and asynchronus programs

//Callbacks
function sum(a,b){
    console.log(a+b);
}
function calculator(a,b,callback){
callback(a,b);
}
calculator(10,20,sum)

//Even number
function filter(number) {
    const result = [];
    for (let i = 0; i < number.length; i++) {
        if (number[i] % 2 === 0) {
            result.push(number[i]);
        }
    }

    for (let i = 0; i < result.length; i++) {
        console.log(result[i]); 
    }
}
const num = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
filter(num);

//
function checkEven(no){
    if(no%2==0){
return true;
    }
}
function checkOdd(no){
    if(no%2!==0){
return true;
    }
}
function filter2(number, check){
    for (let i=0;i<number.length;i++){
        if(check(number[i])){
            result.push(number[i]);
        }
    }
    for(let i=0;i<result.length;i++){
        console.log(result[i]);
    }
}
const num1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
filter2(num1, checkEven);
filter2(num1,checkOdd);

//Callback Doom
//promises
const promise=new Promise((res, rej)=> {
    console.log("");
    setTimeout(()=>{
        res("Network error");
    },7000)
})

//Promise Chaining

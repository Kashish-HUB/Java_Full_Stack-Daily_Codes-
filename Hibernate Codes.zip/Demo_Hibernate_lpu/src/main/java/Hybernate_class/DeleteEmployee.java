package Hybernate_class;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class DeleteEmployee {

	public static void main(String[] args) {
		Configuration con = new Configuration();
		con.configure("hibernate.cfg.xml");
		SessionFactory sf=con.buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Query q=s.createQuery("delete hybernate e set fname=:name where id=:eid");
		q.setParameter("name","Anjali");
		q.setParameter("eid", 10);
		q.executeUpdate();
		t.commit();
		s.close();
	}

}

//string object names
var str="I like javascript";
document.write(str.charAt(7)+"<br>"); 

//date method
const today=new Date();
document.write(today+"<br>");

//alert
var value=alert("Hello");
document.write(value+"<br>");

//cofirm
var value1=confirm("Front-end");
document.write(value1+"<br>");

//prompt
var name1=prompt("Enter your name: ");
document.write(name1+"<br>");

var no1=prompt("Enter your 1st no.: ");
var no2=prompt("Enter your 2nd no.: ");
document.write(parseInt(no1)+parseInt(no2)+"<br>");


var age = prompt("Enter your age:");
let isMale = confirm("Click OK for Male, Cancel for Female.");

if (isMale) { 
    if (age < 21) {
        document.write("Study Hard"+"<br>");
    } else {
        document.write("Work Hard"+"<br>");
    }
} else { 
    if (age < 21) {
        document.write("Enjoy College Life"+"<br>");
    } else {
        document.write("Enjoy Married Life"+"<br>");
    }
}
function openGoogle(){
    open("https://www.google.com");
}
setTimeout(openGoogle, 5000);

function displayTime() {
    let now = new Date(); 
    let timeString = now.toLocaleTimeString();
    document.write("Current Time: " + timeString); 
}
//setTimeout(displayTime, 5000);
const names = ["Kashish", "Simer", "Diksha"];
for (let i = 0; i < names.length; i++) {
    document.write(names[i] + "<br>");
}

const citiesArray = new Array();
citiesArray[0] = "Jalandhar";
citiesArray[1] = "Patiala";
citiesArray[2] = "Bathinda";

for (let i = 0; i < citiesArray.length; i++) {
    document.write(citiesArray[i] + "<br>");
}

function available(cities, cityToCheck) {
    if (cities.includes(cityToCheck)) {
        document.write(cityToCheck + " is available<br>");
    } else {
        document.write(cityToCheck + " is not available<br>");
    }
}

const cityList = ["Jalandhar", "Bathinda", "Patiala", "Amritsar", "Ludhiana"];
available(cityList, "Jalandhar");  
available(cityList, "Sangrur");  

const student = new Object();
student.id = 201;
student.name = "Kashish";
document.write("id: " + student.id + " Name: " + student["name"] + "<br>");

function Teacher(id, name, age) {
    this.id = id;
    this.name = name;
    this.age = age;
}
const obj1 = new Teacher(301, "Simer", 21);
document.write(obj1.id + " " + obj1.name + "<br>");

const test1 = (a) => a;
document.write(test1(100) + "<br>");

function getGrade(marks) {
    switch (true) {
        case (marks >= 90 && marks <= 100):
            return "Congratulations, you got O grade";
        case (marks >= 80 && marks < 90):
            return "Congratulations, you got A grade";
        case (marks >= 70 && marks < 80):
            return "Congratulations, you got B grade";
        case (marks >= 60 && marks < 70):
            return "Congratulations, you got C grade";
        case (marks >= 0 && marks < 60):
            return "Congratulations, you got D grade";
        default:
            return "Invalid Marks";
    }
}

let marks = 100;  
document.write(getGrade(marks) + "<br>");

const person = {
    id: 101,
    name: "Diksha",
    age: 21
};
for (let p in person) {
    document.write(person[p] + "<br>");
}

const square = (a, b = 10) => a * b;
document.write(square(2) + "<br>");

function sum(a = 5, b = 7) {
    return a + b;
}
document.write(sum() + "<br>");
document.write(sum(10) + "<br>");
document.write(sum(10, 10) + "<br>");

function show(...args) {
    let sum = 0;
    for (let i of args) {
        sum += i;
    }
    console.log("Sum = " + sum);
}
show(10, 20, 30);

const n1 = [1, 2, 3, 4, 5, 6, 7];
const n2 = [8, 9, 10];
const result = [...n1, ...n2];
document.write(result + "<br>");

const n4 = [...n1]; // Shallow copy
n4.push(100);
document.write(n1 + "<br>"); // Original array remains unchanged

const person1 = {
    id: 101,
    name: "Akshay",
    age: 30
};
const address = {
    flatNo: 204,
    road:"Model town"
};

const personWithAddress = { ...person1, ...address };
console.log(personWithAddress);
document.write("Merged Object: " + JSON.stringify(personWithAddress));

package lpu;

public interface Bank {
float getRateOfInterest();
}

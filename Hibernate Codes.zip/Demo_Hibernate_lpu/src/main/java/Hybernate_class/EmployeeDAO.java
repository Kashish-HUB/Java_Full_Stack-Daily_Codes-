package Hybernate_class;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmployeeDAO {

	public static void main(String[] args) {
hybernate e =new hybernate();
e.setId(101);
e.setFname("Kashish");
e.setLname("Choudhary");
Configuration con=new Configuration();
con.configure("hibernate.cfg.xml");
SessionFactory sf=con.buildSessionFactory();
Session s=sf.openSession();
Transaction t=s.beginTransaction();
s.save(e);
t.commit();
s.close();

	}

}

package lpu;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

public class TryWithResources {
public static void main(String[] args) throws IOException {
	try(Scanner sc=new Scanner(new File("C:\\Users\\KASHISH\\eclipse-workspace\\lpu\\src\\lpu\\test.txt"))){
			while (sc.hasNext()) {
				System.out.println(sc.nextLine());
			}
}
catch(FileNotFoundException fe) {
	System.out.println(fe);
}
}
}
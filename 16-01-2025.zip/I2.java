package lpu;

public interface I2 {
void show();
}

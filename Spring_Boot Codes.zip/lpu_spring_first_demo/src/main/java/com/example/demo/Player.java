package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class Player {
public void display() {
	System.out.println("I like to play cricket...");
}
}

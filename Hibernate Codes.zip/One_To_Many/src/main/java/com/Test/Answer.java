package com.Test;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ans1")
public class Answer {
@Id
@GeneratedValue(strategy=GenerationType.TABLE)
private int id;
private String answername;
private String postedby;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getAnswername() {
	return answername;
}
public void setAnswername(String answername) {
	this.answername = answername;
}
public String getPostedby() {
	return postedby;
}
public void setPostedby(String postedby) {
	this.postedby = postedby;
}
}

package lpu;

public class SBI implements Bank {

	@Override
	public float getRateOfInterest() {
		return 7.5f;
	}

}

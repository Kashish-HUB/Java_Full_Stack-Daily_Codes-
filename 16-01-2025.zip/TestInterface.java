package lpu;

class TestInterfaceI1 implements I1{
	@Override
	public void display() {
		System.out.println("Override method from I1 interface");
	}

	@Override
	public void show() {
		System.out.println("Override methode from interface I2");
		
	}
}
public class TestInterface {
	public static void main(String[] args) {
		TestInterfaceI1 t=new TestInterfaceI1();
		t.display();
		t.show();
	}

}

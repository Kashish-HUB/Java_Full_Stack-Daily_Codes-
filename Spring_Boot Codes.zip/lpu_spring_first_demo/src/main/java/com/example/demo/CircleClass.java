package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class CircleClass {
    private float radius; 

    public float getRadius() {
        return radius;
    }

    public void setRadius(float radius) {
        this.radius = radius;
    }

    public float getArea() {
        return 3.14f * getRadius() * getRadius();
    }
}

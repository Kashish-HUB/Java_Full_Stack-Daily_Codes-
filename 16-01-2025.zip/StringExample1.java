package lpu;

public class StringExample1 {
	public static void main(String args[]) {
		String str1=" Welcome to Java ";
		String str2="Welcome to Punjab";
		String str3=new String("Welcome to LPU");
		String str4=str1.toLowerCase();
		int count=0;
		for(int i=0;i<str2.length();i++) {
			if(str2.charAt(i)=='a' || str2.charAt(i)=='e' || str2.charAt(i)=='i' || str2.charAt(i)=='o' || str2.charAt(i)=='u' ) {
				count++;
			}
		}
		System.out.println(count);
		System.out.println(str1.toLowerCase());
		System.out.println(str2.toUpperCase());
		System.out.println(str1.startsWith("W"));
		System.out.println(str1.endsWith("b"));
		System.out.println(str1.compareTo(str2));
		System.out.println(str1==str3);
		System.out.println(str1 == str2);
		System.out.println(str1.equalsIgnoreCase(str2));
		System.out.println(str1.trim());
		System.out.println(str1.replace('a', 'o'));
		System.out.println(str1.compareTo(str3));
		System.out.println(str1.equals(str2));
		System.out.println(str1.equals(str3));
		
	}

}

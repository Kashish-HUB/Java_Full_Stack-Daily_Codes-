package com.example.user.service;

import java.util.ArrayList;
import java.util.List;

public class UserServices {  
    Long usrId;
    String name;
    String phone;
    List<ContactServices> contacts = new ArrayList<>();

    public UserServices(Long usrId, String name, String phone) {
        this.usrId = usrId;
        this.name = name;
        this.phone = phone;
    }

    public UserServices(Long usrId, String name, String phone, List<ContactServices> contacts) {
        this.usrId = usrId;
        this.name = name;
        this.phone = phone;
        this.contacts = contacts;
    }

    public Long getUsrId() {
        return usrId;
    }

    public void setUsrId(Long usrId) {
        this.usrId = usrId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public List<ContactServices> getContacts() {
        return contacts;
    }

    public void setContacts(List<ContactServices> contacts) {
        this.contacts = contacts;
    }
}



function forward1(){
    alert("");
    history.forward();
}

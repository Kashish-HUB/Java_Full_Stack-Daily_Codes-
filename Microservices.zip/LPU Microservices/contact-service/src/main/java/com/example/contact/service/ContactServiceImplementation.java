package com.example.contact.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

@Service
public class ContactServiceImplementation implements ContactService{
	List<ContactServices> list=List.of(
new ContactServices(201L,"kashish@gmail.com","Kashish",101L),
new ContactServices(202L,"pinda@gmail.com","Pinda",102L),
new ContactServices(203L,"simer@gmail.com","Simer",103L),
new ContactServices(204L,"diksha@gmail.com","Diksha",104L)
);
	@Override
	public List<ContactServices> getContactofUser(Long id) {
		return list.stream().filter(contactservices->contactservices.getUserId().equals(id)).collect(Collectors.toList());
	}

}

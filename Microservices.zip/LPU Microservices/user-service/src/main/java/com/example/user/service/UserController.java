package com.example.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    RestTemplate rt;
    @Autowired
    private UserServiceImplementation userService; 

    @GetMapping("/{id}")
    public UserServices getUser(@PathVariable Long id) { 
       UserServices userServices=this.userService.getUserbyId(id);
       List contacts=(List<UserServices>) this.rt.getForObject("http://ContactService:9092/contact/user/"+userServices.getUsrId(),List.class);
    		   userServices.setContacts(contacts);
    	return userServices;
    }
}

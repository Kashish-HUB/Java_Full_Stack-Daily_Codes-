package com.example.demo;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
@Table(name="player")
public class PlayerModel {
	public PlayerModel() {}
@Id
	public int id;
@NotBlank(message="name can not be blank")
@Size(min=2,max=10, message="Name must have min 2 and max 10 characters")
private String name;
public PlayerModel(int id, String name) {
	
	this.id = id;
	this.name = name;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {	
	
	this.name = name;
}

}

package myPack;

import org.springframework.stereotype.Component;

@Component
public class Cricketer {
public void cricket() {
	System.out.println("Cricket is famous sport..");
}
}

package com.example.contact.service;

import java.util.List;

public interface ContactService {
public List<ContactServices> getContactofUser(Long id);
}

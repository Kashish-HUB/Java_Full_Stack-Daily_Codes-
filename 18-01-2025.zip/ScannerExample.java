package lpu;

import java.util.Scanner;

public class ScannerExample {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter your id: ");
	int id=sc.nextInt();
	System.out.println("Your id is: "+id);
	System.out.println("Enter your name: ");
	String name=sc.next();
	System.out.println("Your name is: "+name);
	System.out.println("Enter your age: ");
	int age=sc.nextInt();
	System.out.println("Your age is: "+age);
	sc.close();
}
}

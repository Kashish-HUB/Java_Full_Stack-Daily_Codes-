package lpu;

public interface I1 extends I2{
void display();
}

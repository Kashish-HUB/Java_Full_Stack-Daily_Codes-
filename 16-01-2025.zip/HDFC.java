package lpu;

public class HDFC implements Bank{

	@Override
	public float getRateOfInterest() {
		return 8.5f;
	}

}

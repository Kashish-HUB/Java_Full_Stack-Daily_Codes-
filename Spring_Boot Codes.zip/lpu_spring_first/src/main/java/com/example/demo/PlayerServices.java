package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PlayerServices {
	@Autowired
	PlayerJpaRepository pr;
public PlayerServices() {
}

public List<PlayerModel> getAllPlayers(){
	return pr.findAll();
}

public PlayerModel getSinglePlayer(int id) {
Optional<PlayerModel> pm=this.pr.findById(id);
if(pm.isPresent()) {
	return pm.get();}else {
		return null;
}
}
public void savePlayer(PlayerModel p) {
	this.pr.save(p);
}
public void updateplayerService(PlayerModel p1) {
	this.pr.save(p1);
}
public void deletePlayerById(int id) {
pr.deleteById(id);
}
	/*for(PlayerModel p:list) {
	if(p.getId()==id) {
		return p;
	}
}
return null;
}
public void savePlayer(PlayerModel p) {
	this.list.add(p);
	
}
public void updateplayerService(PlayerModel p1) {
	for(PlayerModel p2:list) {
		if(p2.getId()==p1.id) {
			p2.setName(p1.getName());
		}
	}
}
public void deletePlayerById(int id) {
System.out.println(id);
for(PlayerModel p:list) {
	if(p.getId()==id) {
		list.remove(p);
	break;	
	}
}*/
		
}


package com.example.demo;

public class Cutter {
public void Cutting() {
	System.out.println("I like to cut trees");
}
}

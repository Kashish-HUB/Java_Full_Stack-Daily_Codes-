package lpu;

@FunctionalInterface
interface Test7{
	public void display();
}
public class InstanceMethodReference {
public void show() {
	System.out.println("I am binded with instance method");
}
	public static void main(String[] args) {

		InstanceMethodReference im=new InstanceMethodReference();
Test7 t=im::show;
t.display();
	}

}

package lpu;
abstract class TestFinalMethod{
	abstract void show();
	final void display() {
		System.out.println("I am final method from abstract");
	}
}
class GetFinalMethod extends TestFinalMethod{

	@Override
	void show() {
		System.out.println("I am show method from Get final Mthod");
		
	}
	
}
public class TestFinal {

	public static void main(String[] args) {
		final int a =100;
		

	}

}

package com.example.user.service;

public interface UserService {
    public UserServices getUserbyId(Long id);
}

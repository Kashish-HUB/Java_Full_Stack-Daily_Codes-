package Hybernate_class;

import java.util.Iterator;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class SelectData {

	public static void main(String[] args) {
Configuration c = new Configuration();
c.configure("hibernate.cfg.xml");
SessionFactory sf=c.buildSessionFactory();
Session s=sf.openSession();
Transaction t=s.beginTransaction();
Query q=s.createQuery("from hybernate");
List list=q.list();
Iterator<hybernate> itr=list.iterator();
while(itr.hasNext()) {
	hybernate h=itr.next();
System.out.println(h.getId()+""+h.getFname()+" "+h.getLname()+"");	
}


	}

}

package lpu;

public class SB {

	public static void main(String[] args) {
		StringBuffer sb1=new StringBuffer("Hii");
		StringBuilder sb2=new StringBuilder("Hello");
		System.out.println(sb1.capacity());
		System.out.println(sb2.capacity());
		System.out.println(sb2.length());
		System.out.println(sb2.append("I like javaScript"));
		System.out.println(sb1.reverse());
		System.out.println(sb2.indexOf("o"));
		System.out.println(sb2.delete(1, 3));
		// TODO Auto-generated method stub

	}

}

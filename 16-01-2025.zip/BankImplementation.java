package lpu;

public class BankImplementation {
public static void main(String args[]) {
	SBI s=new SBI();
	HDFC h=new HDFC();
	System.out.println(s.getRateOfInterest());
	System.out.println(h.getRateOfInterest());
}
}

package lpu;
@FunctionalInterface
interface Test8{
	public void display(String str);
}
public class ConstructorReference {
	ConstructorReference(String msg){
		System.out.println(msg);
	}

	public static void main(String[] args) {
Test8 t=ConstructorReference::new;
t.display("I like JAVASCRIPT");
	}

}

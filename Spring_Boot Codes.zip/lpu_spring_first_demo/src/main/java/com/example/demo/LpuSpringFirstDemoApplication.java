package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import myPack.Cricketer;

@SpringBootApplication
public class LpuSpringFirstDemoApplication implements CommandLineRunner {
@Autowired
@Qualifier("first")
Cutter c;
@Autowired
Player p;
@Autowired
CircleClass c1;
@Autowired
Cricketer ck;
	public static void main(String[] args) {
		SpringApplication.run(LpuSpringFirstDemoApplication.class, args);
		System.out.println("Hello World");
		System.out.println("Springboot is the best framework");
	}
	@Override
	public void run(String... args) throws Exception {
	this.p.display();
	this.ck.cricket();
	this.c1.setRadius(5);
    System.out.println("Area of Circle: " + this.c1.getArea()); 
	}

}
